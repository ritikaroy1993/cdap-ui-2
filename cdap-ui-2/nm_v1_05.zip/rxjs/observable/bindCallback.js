"use strict";
var BoundCallbackObservable_1 = require('./BoundCallbackObservable');
exports.bindCallback = BoundCallbackObservable_1.BoundCallbackObservable.create;
//# sourceMappingURL=bindCallback.js.map