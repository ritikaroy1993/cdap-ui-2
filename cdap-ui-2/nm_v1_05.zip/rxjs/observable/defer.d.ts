import { DeferObservable } from './DeferObservable';
export declare const defer: typeof DeferObservable.create;
