"use strict";
var Observable_1 = require('../../Observable');
var generate_1 = require('../../observable/generate');
Observable_1.Observable.generate = generate_1.generate;
//# sourceMappingURL=generate.js.map