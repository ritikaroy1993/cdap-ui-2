"use strict";
var Observable_1 = require('../../Observable');
var findIndex_1 = require('../../operator/findIndex');
Observable_1.Observable.prototype.findIndex = findIndex_1.findIndex;
//# sourceMappingURL=findIndex.js.map