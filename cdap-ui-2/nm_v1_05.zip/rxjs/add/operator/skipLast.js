"use strict";
var Observable_1 = require('../../Observable');
var skipLast_1 = require('../../operator/skipLast');
Observable_1.Observable.prototype.skipLast = skipLast_1.skipLast;
//# sourceMappingURL=skipLast.js.map