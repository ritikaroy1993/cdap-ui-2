## History

### 1.1.0 - 16th Aug 2017

- [f4576e3](https://github.com/darsain/remove-trailing-separator/commit/f4576e3638c39b794998b533fffb27854dcbee01) Implement faster slash slicing

### 1.0.2 - 07th Jun 2017

- [8e13ecb](https://github.com/darsain/remove-trailing-separator/commit/8e13ecbfd7b9f5fdf97c5d5ff923e4718b874e31) ES5 compatibility

### 1.0.1 - 25th Sep 2016

- [b78606d](https://github.com/darsain/remove-trailing-separator/commit/af90b4e153a4527894741af6c7005acaeb78606d) Remove backslash only on win32 systems

### 1.0.0 - 24th Sep 2016

Initial release.
