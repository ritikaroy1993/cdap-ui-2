export { default } from './stylis.min'
