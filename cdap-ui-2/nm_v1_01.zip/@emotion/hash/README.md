# @emotion/hash

> A MurmurHash2 implementation

```jsx
import hash from '@emotion/hash'

hash('some-string') // 12fj1d
```

The source of this is from https://github.com/garycourt/murmurhash-js/blob/master/murmurhash2_gc.js.
