# @babel/preset-stage-3

> Babel preset for stage 3 plugins

See our website [@babel/preset-stage-3](https://babeljs.io/docs/en/next/babel-preset-stage-3.html) for more information.

## Install

Using npm:

```sh
npm install --save-dev @babel/preset-stage-3
```

or using yarn:

```sh
yarn add @babel/preset-stage-3 --dev
```
