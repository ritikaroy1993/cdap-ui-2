# @babel/preset-stage-2

> Babel preset for stage 2 plugins

See our website [@babel/preset-stage-2](https://babeljs.io/docs/en/next/babel-preset-stage-2.html) for more information.

## Install

Using npm:

```sh
npm install --save-dev @babel/preset-stage-2
```

or using yarn:

```sh
yarn add @babel/preset-stage-2 --dev
```
