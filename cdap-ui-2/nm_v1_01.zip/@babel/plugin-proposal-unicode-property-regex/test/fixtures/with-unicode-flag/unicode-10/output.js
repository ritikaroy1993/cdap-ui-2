var regex = /[\u{1F1E6}-\u{1F1FF}]/u;
