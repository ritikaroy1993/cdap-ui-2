# 1.2.3

* Bump svgo to v0.7.x.

# 1.2.2

* Now compiled with babel 6.

# 1.2.1

* Bump svgo to v0.6.x.

# 1.2.0

* Adds the ability to pass per-file objects (thanks to @w0rm).

# 1.1.2

* Update code style.

# 1.1.1

* Update documentation.

# 1.1.0

* Refactor internals.

# 1.0.0

* svgmin takes an options object now, instead of a list of plugins

# 0.4.8

* Bump SVGo to v0.5
