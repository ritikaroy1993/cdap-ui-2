'use strict';

module.exports = require('./dist/browser');
