
# 2.0
 - jshint is now a peerDependency, meaning you must install it seperately
 
     npm install jshint gulp-jshint --save-dev
