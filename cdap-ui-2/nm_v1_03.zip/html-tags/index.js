'use strict';
module.exports = require('./html-tags.json');
