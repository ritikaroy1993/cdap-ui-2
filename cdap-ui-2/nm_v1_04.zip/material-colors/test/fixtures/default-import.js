import colors from '../../dist/colors.es2015';
console.log(colors.red['50']);
