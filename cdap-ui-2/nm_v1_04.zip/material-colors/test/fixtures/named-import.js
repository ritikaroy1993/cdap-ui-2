import { red } from '../../dist/colors.es2015';
console.log(red['50']);
