/**
 * ModClean - Default Patterns
 * @author Kyle Ross
 */
"use strict";

module.exports = require('./patterns.json');
