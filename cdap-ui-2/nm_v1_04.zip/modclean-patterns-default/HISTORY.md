# modclean-patterns-default History

## 1.1.2 (7/5/2018)
* Removed some of the additional patterns to handle license files as it was affecting legitimate files in certain modules. (#4)

## 1.1.1 (11/6/2017)
* Add additional patterns to handle license files (@jorrit)

## 1.1.0 (11/6/2017)
* Fix patterns that delete certain modules (#1)
* Added new patterns:
    - `.eslintrc.*` - safe
    - `yarn.lock` - danger

## 1.0.1 (1/13/2016)
* Added `.flowconfig` pattern to `safe` rule.

## 1.0.0 (1/12/2016)
* Initial release
