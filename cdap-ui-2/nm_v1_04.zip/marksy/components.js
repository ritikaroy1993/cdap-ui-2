console.warn(
  'DEPRECATED - Importing "marksy/components" causes a large bundle size. Read updated docs for information on avoiding this. If you want jsx support, import from "marksy/jsx"'
);
module.exports = require('./lib/jsx');
