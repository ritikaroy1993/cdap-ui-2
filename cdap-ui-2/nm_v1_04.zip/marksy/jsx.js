module.exports = require('./lib/jsx');
