# CHANGELOG

The following changelog contains a summary of changes for each release, along with the contributors we can thank. 
For more detail on these changes, check out the [commit log](https://github.com/elwayman02/mini-lr/commits/master).

### 0.1.8 (Sept 25, 2015)

Update body-parser version (@tardyp)

### 0.1.7 (Sept 24, 2015)

Forked tiny-lr and renamed project to mini-lr
npm v3 support (@benelsen)

### 0.1.6 (June 14, 2015)

Latest tiny-lr release before project abandonment