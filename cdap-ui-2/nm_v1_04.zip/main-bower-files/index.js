module.exports = process.env.LIB_COV ? require('./lib-cov') : require('./lib');
