var mbf = require('./index.js');
var files = mbf({ includeSelf: true });

console.log(files);
