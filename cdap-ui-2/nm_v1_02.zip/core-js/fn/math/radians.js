require('../../modules/es7.math.radians');
module.exports = require('../../modules/_core').Math.radians;
