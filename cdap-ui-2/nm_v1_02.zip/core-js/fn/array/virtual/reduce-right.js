require('../../../modules/es6.array.reduce-right');
module.exports = require('../../../modules/_entry-virtual')('Array').reduceRight;
