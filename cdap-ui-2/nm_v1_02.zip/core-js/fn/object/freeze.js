require('../../modules/es6.object.freeze');
module.exports = require('../../modules/_core').Object.freeze;
