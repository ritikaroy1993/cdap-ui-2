require('../modules/es7.weak-set.of');
require('../modules/es7.weak-set.from');
module.exports = require('../modules/_core').WeakSet;
